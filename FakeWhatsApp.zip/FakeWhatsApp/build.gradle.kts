// Archivo de nivel superior: configuración común para todo el proyecto.
// Aquí solo se declaran los plugins; NO van dependencias.
plugins {
    alias(libs.plugins.android.application) apply false
}
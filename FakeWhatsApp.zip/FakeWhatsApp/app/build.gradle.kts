plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.fakewhatsapp"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.fakewhatsapp"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
    // OkHttp: hace las peticiones HTTP (GET, POST...) a Supabase
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Gson: convierte JSON a objetos Java y viceversa
    implementation("com.google.code.gson:gson:2.11.0")

    // RecyclerView: para las listas (contactos, chats, mensajes)
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Glide: carga las fotos de perfil desde internet
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
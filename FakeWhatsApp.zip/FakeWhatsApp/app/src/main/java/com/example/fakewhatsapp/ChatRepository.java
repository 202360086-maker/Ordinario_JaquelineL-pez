package com.example.fakewhatsapp;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Peticiones de conversaciones.
 * Usa funciones RPC de Supabase (funciones SQL que se llaman como una API).
 */
public class ChatRepository {

    public interface Callback<T> {
        void onExito(T resultado);
        void onError(String mensaje);
    }

    private final SessionManager session;
    private final Gson gson = new Gson();
    private final Handler hiloPrincipal = new Handler(Looper.getMainLooper());

    public ChatRepository(SessionManager session) {
        this.session = session;
    }

    // ---------------- CREAR O ABRIR CHAT CON UN CONTACTO ----------------
    public void obtenerOCrearChat(String otroId, Callback<String> cb) {
        JsonObject body = new JsonObject();
        body.addProperty("otro", otroId); // parámetro de la función SQL

        Request request = SupabaseClient.peticion("/rest/v1/rpc/obtener_o_crear_chat",
                        session.getAccessToken())
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String texto) {
                // La función regresa el id como texto JSON: "abc-123..."
                cb.onExito(gson.fromJson(texto, String.class));
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- CONSULTAR MIS CONVERSACIONES ----------------
    public void listarMisChats(Callback<List<Chat>> cb) {
        Request request = SupabaseClient.peticion("/rest/v1/rpc/mis_chats", session.getAccessToken())
                .post(RequestBody.create("{}", SupabaseClient.JSON)) // sin parámetros
                .build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String texto) {
                Chat[] chats = gson.fromJson(texto, Chat[].class);
                cb.onExito(new ArrayList<>(Arrays.asList(chats)));
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- MÉTODO GENERAL ----------------
    private void ejecutar(Request request, Callback<String> cb) {
        SupabaseClient.getClient().newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                hiloPrincipal.post(() -> cb.onError("Sin conexión: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String texto = response.body() != null ? response.body().string() : "";
                if (response.isSuccessful()) {
                    hiloPrincipal.post(() -> cb.onExito(texto));
                } else {
                    String error = extraerError(texto);
                    hiloPrincipal.post(() -> cb.onError(error));
                }
            }
        });
    }

    private String extraerError(String texto) {
        try {
            JsonObject json = JsonParser.parseString(texto).getAsJsonObject();
            if (json.has("message")) return json.get("message").getAsString();
            if (json.has("msg")) return json.get("msg").getAsString();
        } catch (Exception ignored) { }
        return texto;
    }
}
package com.example.fakewhatsapp;

import com.google.gson.annotations.SerializedName;

/**
 * MODELO: una fila de la lista de chats.
 * Viene de la función mis_chats() de Supabase.
 */
public class Chat {

    @SerializedName("conversation_id")
    public String conversationId;   // id de la conversación

    @SerializedName("otro_id")
    public String otroId;           // id del otro participante

    @SerializedName("otro_nombre")
    public String otroNombre;       // su nombre

    @SerializedName("otro_avatar")
    public String otroAvatar;       // su foto

    @SerializedName("ultimo_mensaje")
    public String ultimoMensaje;    // texto del último mensaje (null si no hay)

    @SerializedName("ultimo_remitente")
    public String ultimoRemitente;  // quién envió el último mensaje

    @SerializedName("ultima_fecha")
    public String ultimaFecha;      // fecha del último movimiento
}
package com.example.fakewhatsapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Pantalla "Seleccionar contacto":
 * lista de usuarios con buscador. Al tocar uno, crea (o reutiliza)
 * la conversación y abre el chat.
 */
public class ContactosActivity extends AppCompatActivity {

    private ContactoAdapter adapter;
    private TextView tvConteo, tvVacio;
    private ProgressBar progress;
    private boolean creandoChat = false; // evita crear dos veces si tocan rápido

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactos);

        tvConteo = findViewById(R.id.tvConteo);
        tvVacio = findViewById(R.id.tvVacio);
        progress = findViewById(R.id.progress);
        EditText etBuscar = findViewById(R.id.etBuscar);

        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());

        // ---- RecyclerView ----
        RecyclerView rv = findViewById(R.id.rvContactos);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ContactoAdapter(this::seleccionarContacto);
        rv.setAdapter(adapter);

        // ---- Buscador: filtra mientras escribes ----
        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filtrar(s.toString());
                actualizarVista();
            }
        });

        cargarContactos();
    }

    /** Pide a Supabase la lista de usuarios */
    private void cargarContactos() {
        progress.setVisibility(View.VISIBLE);
        new PerfilRepository(new SessionManager(this)).listarContactos(
                new PerfilRepository.Callback<List<Perfil>>() {
                    @Override
                    public void onExito(List<Perfil> lista) {
                        progress.setVisibility(View.GONE);
                        adapter.setContactos(lista);
                        actualizarVista();
                    }

                    @Override
                    public void onError(String mensaje) {
                        progress.setVisibility(View.GONE);
                        Toast.makeText(ContactosActivity.this, "Error: " + mensaje, Toast.LENGTH_LONG).show();
                    }
                });
    }

    /** Actualiza el contador y el mensaje de "sin resultados" */
    private void actualizarVista() {
        int n = adapter.getCantidadVisible();
        tvConteo.setText(n + (n == 1 ? " contacto" : " contactos"));
        tvVacio.setVisibility(n == 0 ? View.VISIBLE : View.GONE);
    }

    /** Al tocar un contacto: crear/reutilizar la conversación y abrir el chat */
    private void seleccionarContacto(Perfil perfil) {
        if (creandoChat) return;
        creandoChat = true;
        progress.setVisibility(View.VISIBLE);

        new ChatRepository(new SessionManager(this)).obtenerOCrearChat(perfil.id,
                new ChatRepository.Callback<String>() {
                    @Override
                    public void onExito(String conversationId) {
                        progress.setVisibility(View.GONE);
                        // Abrimos directo la pantalla del chat con sus datos
                        Intent i = new Intent(ContactosActivity.this, ChatActivity.class);
                        i.putExtra(ChatActivity.EXTRA_CONVERSACION, conversationId);
                        i.putExtra(ChatActivity.EXTRA_OTRO_ID, perfil.id);
                        i.putExtra(ChatActivity.EXTRA_OTRO_NOMBRE, perfil.getNombreVisible());
                        i.putExtra(ChatActivity.EXTRA_OTRO_AVATAR, perfil.avatarUrl);
                        startActivity(i);
                        finish(); // cierra contactos para que "atrás" regrese a la lista de chats
                    }

                    @Override
                    public void onError(String mensaje) {
                        creandoChat = false;
                        progress.setVisibility(View.GONE);
                        Toast.makeText(ContactosActivity.this, "Error: " + mensaje, Toast.LENGTH_LONG).show();
                    }
                });
    }
}
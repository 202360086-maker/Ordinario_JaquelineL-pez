package com.example.fakewhatsapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Pantalla del chat:
 * - Fase 6: historial, burbujas y envío
 * - Fase 7: mensajes nuevos al instante (Realtime)
 * - Fase 8: palomitas, última conexión y "escribiendo..."
 */
public class ChatActivity extends AppCompatActivity implements RealtimeClient.Listener {

    // Claves para recibir los datos del chat desde otras pantallas
    public static final String EXTRA_CONVERSACION = "conversacion";
    public static final String EXTRA_OTRO_ID = "otro_id";
    public static final String EXTRA_OTRO_NOMBRE = "otro_nombre";
    public static final String EXTRA_OTRO_AVATAR = "otro_avatar";

    private SessionManager session;
    private MensajeRepository repo;
    private final RealtimeClient realtime = new RealtimeClient();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private MensajeAdapter adapter;
    private RecyclerView rv;
    private EditText etMensaje;
    private TextView tvEstado;

    private String convId, otroId;
    private String estadoOtro = "";          // "en línea" o "últ. vez..."
    private boolean mostrandoEscribiendo = false;
    private long ultimoAvisoEscribiendo = 0;

    // Quita "escribiendo..." después de 3 segundos sin avisos
    private final Runnable quitarEscribiendo = () -> {
        mostrandoEscribiendo = false;
        tvEstado.setText(estadoOtro);
    };

    // Cada 30 s: guardo mi conexión y reviso la del otro
    private final Runnable latidoConexion = new Runnable() {
        @Override
        public void run() {
            repo.actualizarConexion();
            cargarEstadoOtro();
            handler.postDelayed(this, 30000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Mueve la caja de texto arriba del teclado (Android 15+)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.raizChat), (v, insets) -> {
            Insets teclado = insets.getInsets(WindowInsetsCompat.Type.ime());
            Insets barra = insets.getInsets(WindowInsetsCompat.Type.navigationBars());
            v.setPadding(0, 0, 0, Math.max(teclado.bottom, barra.bottom));
            return insets;
        });

        session = new SessionManager(this);
        repo = new MensajeRepository(session);

        // ---- Datos que mandó la pantalla anterior ----
        convId = getIntent().getStringExtra(EXTRA_CONVERSACION);
        otroId = getIntent().getStringExtra(EXTRA_OTRO_ID);
        String nombre = getIntent().getStringExtra(EXTRA_OTRO_NOMBRE);
        String avatar = getIntent().getStringExtra(EXTRA_OTRO_AVATAR);

        // ---- Barra superior ----
        ((TextView) findViewById(R.id.tvNombre)).setText(nombre);
        AvatarUtil.mostrar((ImageView) findViewById(R.id.ivAvatar), avatar);
        tvEstado = findViewById(R.id.tvEstado);
        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());

        // ---- Lista de mensajes ----
        rv = findViewById(R.id.rvMensajes);
        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true); // empieza desde abajo, como WhatsApp
        rv.setLayoutManager(lm);
        adapter = new MensajeAdapter(session.getUserId());
        rv.setAdapter(adapter);
        // Al abrir el teclado, baja al último mensaje
        rv.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (b < ob) rv.post(this::bajarAlFinal);
        });

        // ---- Caja de texto y botón enviar ----
        etMensaje = findViewById(R.id.etMensaje);
        findViewById(R.id.btnEnviar).setOnClickListener(v -> enviar());
        etMensaje.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                avisarEscribiendo();
            }
        });

        cargarMensajes();
        realtime.conectar(convId, session.getAccessToken(), this); // Fase 7
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(latidoConexion);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(latidoConexion);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        realtime.desconectar();
        handler.removeCallbacksAndMessages(null);
    }

    // ================= FASE 6 =================

    /** Consultar historial */
    private void cargarMensajes() {
        repo.listarMensajes(convId, new MensajeRepository.Callback<List<Mensaje>>() {
            @Override
            public void onExito(List<Mensaje> lista) {
                adapter.setMensajes(lista);
                bajarAlFinal();
                repo.marcarLeidos(convId); // Fase 8: los que me mandaron pasan a "leído"
            }

            @Override
            public void onError(String m) {
                Toast.makeText(ChatActivity.this, "Error: " + m, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Insertar mensaje en PostgreSQL */
    private void enviar() {
        String texto = etMensaje.getText().toString().trim();
        if (texto.isEmpty()) return;
        etMensaje.setText("");

        repo.enviarMensaje(convId, texto, new MensajeRepository.Callback<Mensaje>() {
            @Override
            public void onExito(Mensaje m) {
                if (adapter.agregar(m)) bajarAlFinal();
            }

            @Override
            public void onError(String error) {
                etMensaje.setText(texto); // regresa el texto para no perderlo
                Toast.makeText(ChatActivity.this, "No se envió: " + error, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void bajarAlFinal() {
        if (adapter.getItemCount() > 0) rv.scrollToPosition(adapter.getItemCount() - 1);
    }

    // ================= FASE 7 (Realtime) =================

    /** Llegó un mensaje nuevo al instante */
    @Override
    public void onMensajeNuevo(Mensaje m) {
        if (adapter.agregar(m)) bajarAlFinal();

        if (!session.getUserId().equals(m.senderId)) {
            repo.marcarLeidos(convId); // estoy viendo el chat → leído
            handler.removeCallbacks(quitarEscribiendo);
            quitarEscribiendo.run();   // ya no está escribiendo
        }
    }

    /** Cambió un mensaje (sus palomitas) */
    @Override
    public void onMensajeActualizado(Mensaje m) {
        adapter.actualizar(m);
    }

    // ================= FASE 8 (estados) =================

    /** El otro está escribiendo */
    @Override
    public void onEscribiendo(String userId) {
        if (!userId.equals(otroId)) return;
        mostrandoEscribiendo = true;
        tvEstado.setText("escribiendo...");
        handler.removeCallbacks(quitarEscribiendo);
        handler.postDelayed(quitarEscribiendo, 3000);
    }

    /** Avisar que yo escribo (máximo una vez cada 2 s para no saturar) */
    private void avisarEscribiendo() {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimoAvisoEscribiendo > 2000) {
            realtime.enviarEscribiendo(session.getUserId());
            ultimoAvisoEscribiendo = ahora;
        }
    }

    /** Última conexión del otro */
    private void cargarEstadoOtro() {
        repo.obtenerPerfil(otroId, new MensajeRepository.Callback<Perfil>() {
            @Override
            public void onExito(Perfil p) {
                estadoOtro = FechaUtil.ultimaVez(p.lastSeen);
                if (!mostrandoEscribiendo) tvEstado.setText(estadoOtro);
            }
            @Override public void onError(String m) { }
        });
    }
}
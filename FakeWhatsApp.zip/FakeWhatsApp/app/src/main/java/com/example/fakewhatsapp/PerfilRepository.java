package com.example.fakewhatsapp;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Peticiones relacionadas con perfiles:
 * consultar mi perfil, listar contactos, actualizar datos y subir foto.
 */
public class PerfilRepository {

    /** Callback genérico: T es el tipo de dato que regresa (Perfil, List, String...) */
    public interface Callback<T> {
        void onExito(T resultado);
        void onError(String mensaje);
    }

    private final SessionManager session;
    private final Gson gson = new Gson();
    private final Handler hiloPrincipal = new Handler(Looper.getMainLooper());

    public PerfilRepository(SessionManager session) {
        this.session = session;
    }

    // ---------------- CONSULTAR MI PERFIL ----------------
    public void obtenerMiPerfil(Callback<Perfil> cb) {
        // id=eq.XXX → "donde id sea igual a XXX"
        String ruta = "/rest/v1/profiles?select=*&id=eq." + session.getUserId();
        Request request = SupabaseClient.peticion(ruta, session.getAccessToken()).get().build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String texto) {
                // Supabase siempre regresa una lista, aunque sea de 1 elemento
                Perfil[] perfiles = gson.fromJson(texto, Perfil[].class);
                if (perfiles != null && perfiles.length > 0) cb.onExito(perfiles[0]);
                else cb.onError("No se encontró tu perfil");
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- CONSULTAR USUARIOS (CONTACTOS) ----------------
    public void listarContactos(Callback<List<Perfil>> cb) {
        // id=neq.XXX → "todos MENOS yo"; order → ordenados por nombre
        String ruta = "/rest/v1/profiles?select=*&id=neq." + session.getUserId()
                + "&order=display_name.asc";
        Request request = SupabaseClient.peticion(ruta, session.getAccessToken()).get().build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String texto) {
                Perfil[] perfiles = gson.fromJson(texto, Perfil[].class);
                cb.onExito(new ArrayList<>(Arrays.asList(perfiles)));
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- ACTUALIZAR NOMBRE, INFO Y FOTO ----------------
    public void actualizarPerfil(String nombre, String info, String avatarUrl, Callback<Void> cb) {
        JsonObject body = new JsonObject();
        body.addProperty("display_name", nombre);
        body.addProperty("about", info);
        if (avatarUrl != null) body.addProperty("avatar_url", avatarUrl); // solo si hay foto nueva

        // PATCH = modificar solo los campos que mandamos
        Request request = SupabaseClient.peticion("/rest/v1/profiles?id=eq." + session.getUserId(),
                        session.getAccessToken())
                .addHeader("Prefer", "return=minimal")
                .patch(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();

        ejecutar(request, new Callback<String>() {
            @Override public void onExito(String t) { cb.onExito(null); }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- SUBIR FOTO A STORAGE ----------------
    public void subirFoto(byte[] imagen, Callback<String> cb) {
        // Cada usuario guarda su foto en SU carpeta: avatars/<su-id>/avatar.jpg
        String ruta = session.getUserId() + "/avatar.jpg";

        Request request = SupabaseClient.peticion("/storage/v1/object/avatars/" + ruta,
                        session.getAccessToken())
                .header("Content-Type", "image/jpeg")
                .header("x-upsert", "true") // si ya existe, la reemplaza
                .post(RequestBody.create(imagen, MediaType.get("image/jpeg")))
                .build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String t) {
                // URL pública de la foto. El "?v=" evita que se quede la foto vieja en caché
                String url = SupabaseClient.SUPABASE_URL + "/storage/v1/object/public/avatars/"
                        + ruta + "?v=" + System.currentTimeMillis();
                cb.onExito(url);
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- MÉTODO GENERAL ----------------
    /** Ejecuta la petición en segundo plano y regresa el texto de la respuesta */
    private void ejecutar(Request request, Callback<String> cb) {
        SupabaseClient.getClient().newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                hiloPrincipal.post(() -> cb.onError("Sin conexión: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String texto = response.body() != null ? response.body().string() : "";
                if (response.isSuccessful()) {
                    hiloPrincipal.post(() -> cb.onExito(texto));
                } else {
                    String error = extraerError(texto);
                    hiloPrincipal.post(() -> cb.onError(error));
                }
            }
        });
    }

    /** Saca el mensaje de error que manda Supabase */
    private String extraerError(String texto) {
        try {
            JsonObject json = JsonParser.parseString(texto).getAsJsonObject();
            if (json.has("message")) return json.get("message").getAsString();
            if (json.has("msg")) return json.get("msg").getAsString();
            if (json.has("error")) return json.get("error").getAsString();
        } catch (Exception ignored) { }
        return texto;
    }
}
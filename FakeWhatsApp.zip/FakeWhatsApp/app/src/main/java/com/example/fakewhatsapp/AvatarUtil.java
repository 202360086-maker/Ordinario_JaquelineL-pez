package com.example.fakewhatsapp;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.widget.ImageView;

import androidx.core.widget.ImageViewCompat;

import com.bumptech.glide.Glide;

/**
 * Ayudante para mostrar fotos de perfil redondas.
 * - Si hay foto → la carga con Glide y la recorta en círculo
 * - Si no hay → muestra el muñequito blanco sobre fondo gris (como WhatsApp)
 */
public class AvatarUtil {

    /** @param fuente puede ser una URL (String) o una imagen elegida del celular (Uri) */
    public static void mostrar(ImageView iv, Object fuente) {
        // Cancela cargas anteriores (importante en RecyclerView, donde las filas se reciclan)
        Glide.with(iv).clear(iv);
        iv.setBackgroundResource(R.drawable.bg_avatar);

        boolean sinFoto = fuente == null
                || (fuente instanceof String && ((String) fuente).isEmpty());

        if (sinFoto) {
            // Muñequito blanco con margen interno (20% del tamaño)
            int margen = iv.getLayoutParams().width / 5;
            iv.setPadding(margen, margen, margen, margen);
            iv.setImageResource(R.drawable.ic_person);
            ImageViewCompat.setImageTintList(iv, ColorStateList.valueOf(Color.WHITE));
        } else {
            // Foto real, sin margen y sin color encima
            iv.setPadding(0, 0, 0, 0);
            ImageViewCompat.setImageTintList(iv, null);
            Glide.with(iv)
                    .load(fuente)
                    .circleCrop()                      // recorta en círculo
                    .placeholder(R.drawable.bg_avatar) // mientras carga
                    .into(iv);
        }
    }
}
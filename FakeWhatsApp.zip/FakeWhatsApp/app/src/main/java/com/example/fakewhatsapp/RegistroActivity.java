package com.example.fakewhatsapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;

/**
 * Pantalla de registro: crea la cuenta en Supabase Auth
 * y después crea su fila en la tabla "profiles".
 */
public class RegistroActivity extends AppCompatActivity {

    private EditText etNombre, etCorreo, etPassword, etConfirmar;
    private Button btnRegistrar;
    private ProgressBar progress;

    private final AuthRepository auth = new AuthRepository();
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        session = new SessionManager(this);

        // Conectamos las variables con los IDs del XML
        etNombre = findViewById(R.id.etNombre);
        etCorreo = findViewById(R.id.etCorreo);
        etPassword = findViewById(R.id.etPassword);
        etConfirmar = findViewById(R.id.etConfirmar);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        progress = findViewById(R.id.progress);

        // Botón principal: registrar
        btnRegistrar.setOnClickListener(v -> registrar());

        // Flecha y enlace "Inicia sesión": regresan al login
        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());
        findViewById(R.id.tvIrLogin).setOnClickListener(v -> finish());
    }

    private void registrar() {
        // Leemos lo que escribió el usuario (trim quita espacios al inicio y al final)
        String nombre = etNombre.getText().toString().trim();
        String correo = etCorreo.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmar = etConfirmar.getText().toString();

        // ---- Validaciones antes de mandar a Supabase ----
        if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6) {
            Toast.makeText(this, "La contraseña debe tener mínimo 6 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!password.equals(confirmar)) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return;
        }

        cargando(true);

        // 1) Creamos la cuenta en Supabase Auth
        auth.registrar(correo, password, nombre, new AuthRepository.AuthCallback() {
            @Override
            public void onExito(JsonObject r) {
                // Si "Confirm email" estuviera activo, Supabase NO manda token
                if (!r.has("access_token")) {
                    cargando(false);
                    Toast.makeText(RegistroActivity.this,
                            "Cuenta creada. Revisa tu correo para confirmarla", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }

                // Sacamos el token (JWT) y el id del usuario
                String token = r.get("access_token").getAsString();
                String userId = r.getAsJsonObject("user").get("id").getAsString();

                // Guardamos la sesión en el celular
                session.guardarSesion(token,
                        r.get("refresh_token").getAsString(),
                        r.get("expires_in").getAsLong(),
                        userId);

                // 2) Creamos su fila en la tabla profiles
                auth.crearPerfil(token, userId, correo, nombre, new AuthRepository.AuthCallback() {
                    @Override
                    public void onExito(JsonObject r2) {
                        Toast.makeText(RegistroActivity.this, "¡Bienvenida/o!", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(RegistroActivity.this, MainActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    }

                    @Override
                    public void onError(String mensaje) {
                        cargando(false);
                        Toast.makeText(RegistroActivity.this,
                                "Error al crear perfil: " + mensaje, Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String mensaje) {
                cargando(false);
                Toast.makeText(RegistroActivity.this, "Error: " + mensaje, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Muestra el círculo de carga y desactiva el botón para que no lo presionen dos veces */
    private void cargando(boolean si) {
        progress.setVisibility(si ? View.VISIBLE : View.GONE);
        btnRegistrar.setEnabled(!si);
    }
}
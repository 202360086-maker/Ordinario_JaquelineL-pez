package com.example.fakewhatsapp;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Clase central para conectarnos con Supabase.
 * Aquí guardamos la URL y la clave, y armamos las peticiones.
 */
public class SupabaseClient {

    // URL de tu proyecto FakeWhatsApp en Supabase
    public static final String SUPABASE_URL = "https://rtxinqaroatmnayhwhlw.supabase.co";

    // Clave pública (publishable). Es segura para ir dentro de la app
    public static final String SUPABASE_KEY = "sb_publishable_Y0u1IyZLoCvSO_HfmrViCQ_TCbvCWEY";

    // Tipo de dato que enviamos: JSON
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    // Un solo cliente HTTP para toda la app (ahorra memoria)
    private static OkHttpClient client;

    /** Regresa el cliente HTTP. Si no existe, lo crea (patrón Singleton). */
    public static OkHttpClient getClient() {
        if (client == null) {
            client = new OkHttpClient();
        }
        return client;
    }

    /**
     * Prepara una petición a Supabase con los encabezados obligatorios.
     * @param ruta  parte final de la URL, ej: "/rest/v1/profiles"
     * @param token JWT del usuario logueado (null si todavía no inicia sesión)
     */
    public static Request.Builder peticion(String ruta, String token) {
        Request.Builder builder = new Request.Builder()
                .url(SUPABASE_URL + ruta)               // URL completa
                .addHeader("apikey", SUPABASE_KEY)      // Clave del proyecto (siempre va)
                .addHeader("Content-Type", "application/json");

        // Si el usuario ya inició sesión, mandamos su JWT para que Supabase sepa QUIÉN es
        if (token != null) {
            builder.addHeader("Authorization", "Bearer " + token);
        }
        return builder;
    }
}
package com.example.fakewhatsapp;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Formatos de fecha estilo WhatsApp (Supabase guarda en UTC) */
public class FechaUtil {

    /** "2026-11-11T20:35:10.123+00:00" → Date */
    public static Date convertir(String iso) {
        if (iso == null || iso.length() < 19) return null;
        try {
            SimpleDateFormat entrada = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            entrada.setTimeZone(TimeZone.getTimeZone("UTC"));
            return entrada.parse(iso.substring(0, 19));
        } catch (Exception e) {
            return null;
        }
    }

    /** Lista de chats: "20:35", "Ayer" o "09/11/26" */
    public static String formatear(String iso) {
        Date fecha = convertir(iso);
        if (fecha == null) return "";
        if (esHoy(fecha)) return hora(iso);
        if (esAyer(fecha)) return "Ayer";
        return new SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(fecha);
    }

    /** Hora de cada burbuja: "20:35" */
    public static String hora(String iso) {
        Date fecha = convertir(iso);
        if (fecha == null) return "";
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(fecha);
    }

    /** Última conexión: "en línea", "últ. vez hoy a las 20:35"... */
    public static String ultimaVez(String iso) {
        Date fecha = convertir(iso);
        if (fecha == null) return "";
        long diferencia = System.currentTimeMillis() - fecha.getTime();
        if (diferencia < 70000) return "en línea"; // activo en el último minuto
        if (esHoy(fecha)) return "últ. vez hoy a las " + hora(iso);
        if (esAyer(fecha)) return "últ. vez ayer a las " + hora(iso);
        return "últ. vez el " + new SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(fecha);
    }

    private static boolean esHoy(Date d) {
        return mismoDia(d, Calendar.getInstance());
    }

    private static boolean esAyer(Date d) {
        Calendar ayer = Calendar.getInstance();
        ayer.add(Calendar.DAY_OF_YEAR, -1);
        return mismoDia(d, ayer);
    }

    private static boolean mismoDia(Date d, Calendar otro) {
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        return c.get(Calendar.YEAR) == otro.get(Calendar.YEAR)
                && c.get(Calendar.DAY_OF_YEAR) == otro.get(Calendar.DAY_OF_YEAR);
    }
}
package com.example.fakewhatsapp;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * ADAPTER de mensajes con DOS tipos de fila:
 * - ENVIADO (mío): burbuja verde a la derecha con palomitas
 * - RECIBIDO: burbuja blanca a la izquierda
 */
public class MensajeAdapter extends RecyclerView.Adapter<MensajeAdapter.MensajeViewHolder> {

    private static final int ENVIADO = 1;
    private static final int RECIBIDO = 2;

    private final List<Mensaje> mensajes = new ArrayList<>();
    private final String miId;

    public MensajeAdapter(String miId) {
        this.miId = miId;
    }

    public void setMensajes(List<Mensaje> lista) {
        mensajes.clear();
        mensajes.addAll(lista);
        notifyDataSetChanged();
    }

    /** Agrega un mensaje nuevo (si no estaba ya). Regresa true si se agregó */
    public boolean agregar(Mensaje m) {
        for (Mensaje x : mensajes) {
            if (x.id != null && x.id.equals(m.id)) return false; // evita duplicados
        }
        mensajes.add(m);
        notifyItemInserted(mensajes.size() - 1);
        return true;
    }

    /** Actualiza un mensaje existente (cuando cambia su estado) */
    public void actualizar(Mensaje m) {
        for (int i = 0; i < mensajes.size(); i++) {
            if (mensajes.get(i).id.equals(m.id)) {
                mensajes.set(i, m);
                notifyItemChanged(i);
                return;
            }
        }
    }

    /** Diferenciar mensajes enviados y recibidos */
    @Override
    public int getItemViewType(int position) {
        return miId.equals(mensajes.get(position).senderId) ? ENVIADO : RECIBIDO;
    }

    @NonNull
    @Override
    public MensajeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = viewType == ENVIADO ? R.layout.item_mensaje_enviado : R.layout.item_mensaje_recibido;
        View vista = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        return new MensajeViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull MensajeViewHolder h, int position) {
        Mensaje m = mensajes.get(position);
        h.tvTexto.setText(m.content);
        h.tvHora.setText(FechaUtil.hora(m.createdAt));

        // Palomitas (solo en mis mensajes)
        if (h.ivEstado != null) {
            int icono;
            int color;
            if ("read".equals(m.status)) {               // Leído: 2 azules
                icono = R.drawable.ic_check_double;
                color = R.color.wa_blue;
            } else if ("delivered".equals(m.status)) {   // Recibido: 2 grises
                icono = R.drawable.ic_check_double;
                color = R.color.texto_secundario;
            } else {                                     // Enviado: 1 gris
                icono = R.drawable.ic_check_single;
                color = R.color.texto_secundario;
            }
            h.ivEstado.setImageResource(icono);
            ImageViewCompat.setImageTintList(h.ivEstado,
                    ColorStateList.valueOf(ContextCompat.getColor(h.itemView.getContext(), color)));
        }
    }

    @Override
    public int getItemCount() {
        return mensajes.size();
    }

    static class MensajeViewHolder extends RecyclerView.ViewHolder {
        TextView tvTexto, tvHora;
        ImageView ivEstado; // null en mensajes recibidos

        MensajeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTexto = itemView.findViewById(R.id.tvTexto);
            tvHora = itemView.findViewById(R.id.tvHora);
            ivEstado = itemView.findViewById(R.id.ivEstado);
        }
    }
}
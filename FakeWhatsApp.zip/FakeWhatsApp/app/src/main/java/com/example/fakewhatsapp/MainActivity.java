package com.example.fakewhatsapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.gson.JsonObject;

import java.util.List;

/**
 * Pantalla principal:
 * - Revisa la sesión (y renueva el JWT si caducó)
 * - Muestra mi foto y la LISTA DE CHATS
 * - Botón flotante → contactos | Mi foto → perfil | Ícono → cerrar sesión
 */
public class MainActivity extends AppCompatActivity {

    private SessionManager session;
    private final AuthRepository auth = new AuthRepository();

    private ImageView ivMiFoto;
    private TextView tvSaludo;
    private RecyclerView rvChats;
    private View layoutVacio;
    private ChatAdapter chatAdapter;

    private boolean sesionLista = false; // true cuando ya validamos la sesión

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        session = new SessionManager(this);
        ivMiFoto = findViewById(R.id.ivMiFoto);
        tvSaludo = findViewById(R.id.tvSaludo);
        rvChats = findViewById(R.id.rvChats);
        layoutVacio = findViewById(R.id.layoutVacio);

        // ---- RecyclerView de chats ----
        rvChats.setLayoutManager(new LinearLayoutManager(this));
        chatAdapter = new ChatAdapter(session.getUserId(), this::abrirChat);
        rvChats.setAdapter(chatAdapter);

        // ---- Navegación ----
        ivMiFoto.setOnClickListener(v -> startActivity(new Intent(this, PerfilActivity.class)));
        findViewById(R.id.fabNuevoChat).setOnClickListener(v ->
                startActivity(new Intent(this, ContactosActivity.class)));
        findViewById(R.id.btnSalir).setOnClickListener(v -> confirmarCerrarSesion());

        AvatarUtil.mostrar(ivMiFoto, null);
        verificarSesion();
    }

    /** Cada vez que regresamos a esta pantalla, recargamos perfil y chats */
    @Override
    protected void onResume() {
        super.onResume();
        if (sesionLista) cargarDatos();
    }

    private void verificarSesion() {
        // 1. Sin sesión → login
        if (!session.haySesion()) {
            irALogin();
            return;
        }

        // 2. JWT caducado → renovarlo
        if (session.tokenExpirado()) {
            auth.renovarToken(session.getRefreshToken(), new AuthRepository.AuthCallback() {
                @Override
                public void onExito(JsonObject r) {
                    session.guardarSesion(
                            r.get("access_token").getAsString(),
                            r.get("refresh_token").getAsString(),
                            r.get("expires_in").getAsLong(),
                            session.getUserId());
                    sesionLista = true;
                    cargarDatos();
                }

                @Override
                public void onError(String mensaje) {
                    session.cerrarSesion();
                    irALogin();
                }
            });
            return;
        }

        // 3. Sesión válida
        sesionLista = true;
        cargarDatos();
    }

    private void cargarDatos() {
        cargarMiPerfil();
        cargarChats();
        MensajeRepository mr = new MensajeRepository(session);
        mr.marcarRecibidos();    // Fase 8: mensajes que me llegaron → "recibido" (2 palomitas grises)
        mr.actualizarConexion(); // Fase 8: guardar mi última conexión
    }

    /** Mi nombre y foto */
    private void cargarMiPerfil() {
        new PerfilRepository(session).obtenerMiPerfil(new PerfilRepository.Callback<Perfil>() {
            @Override
            public void onExito(Perfil p) {
                tvSaludo.setText("Hola, " + p.getNombreVisible() + " 👋");
                AvatarUtil.mostrar(ivMiFoto, p.avatarUrl);
            }
            @Override public void onError(String m) { }
        });
    }

    /** Lista de conversaciones con su último mensaje */
    private void cargarChats() {
        new ChatRepository(session).listarMisChats(new ChatRepository.Callback<List<Chat>>() {
            @Override
            public void onExito(List<Chat> chats) {
                chatAdapter.setChats(chats);
                // Si no hay chats, mostramos el estado vacío
                boolean vacio = chats.isEmpty();
                rvChats.setVisibility(vacio ? View.GONE : View.VISIBLE);
                layoutVacio.setVisibility(vacio ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onError(String m) {
                Toast.makeText(MainActivity.this, "Error al cargar chats: " + m, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Al tocar un chat de la lista */
    /** Al tocar un chat: abrir la pantalla del chat con sus datos */
    private void abrirChat(Chat chat) {
        Intent i = new Intent(this, ChatActivity.class);
        i.putExtra(ChatActivity.EXTRA_CONVERSACION, chat.conversationId);
        i.putExtra(ChatActivity.EXTRA_OTRO_ID, chat.otroId);
        i.putExtra(ChatActivity.EXTRA_OTRO_NOMBRE, chat.otroNombre);
        i.putExtra(ChatActivity.EXTRA_OTRO_AVATAR, chat.otroAvatar);
        startActivity(i);
    }
    /** Pregunta antes de cerrar sesión */
    private void confirmarCerrarSesion() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Cerrar sesión")
                .setMessage("¿Seguro que quieres salir de FakeWhatsApp?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Salir", (d, w) -> cerrarSesion())
                .show();
    }

    private void cerrarSesion() {
        auth.cerrarSesion(session.getAccessToken(), new AuthRepository.AuthCallback() {
            @Override public void onExito(JsonObject r) { salir(); }
            @Override public void onError(String m) { salir(); }
        });
    }

    private void salir() {
        session.cerrarSesion();
        irALogin();
    }

    private void irALogin() {
        Intent i = new Intent(this, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }
}
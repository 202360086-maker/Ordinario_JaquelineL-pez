package com.example.fakewhatsapp;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * ADAPTER de la lista de chats (pantalla principal).
 * Cada fila: foto, nombre, último mensaje y hora.
 */
public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    public interface OnChatClick {
        void onClick(Chat chat);
    }

    private final List<Chat> chats = new ArrayList<>();
    private final String miId;            // para saber si el último mensaje lo mandé yo
    private final OnChatClick listener;

    public ChatAdapter(String miId, OnChatClick listener) {
        this.miId = miId;
        this.listener = listener;
    }

    public void setChats(List<Chat> lista) {
        chats.clear();
        chats.addAll(lista);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder h, int position) {
        Chat c = chats.get(position);

        h.tvNombre.setText(c.otroNombre != null ? c.otroNombre : "Sin nombre");
        h.tvHora.setText(FechaUtil.formatear(c.ultimaFecha));
        AvatarUtil.mostrar(h.ivAvatar, c.otroAvatar);

        // Último mensaje
        if (c.ultimoMensaje == null) {
            // Chat recién creado, sin mensajes
            h.tvUltimo.setText("Toca para empezar a chatear");
            h.tvUltimo.setTypeface(null, Typeface.ITALIC);
        } else {
            // Si yo lo envié, se antepone "Tú: " (como WhatsApp)
            String prefijo = miId != null && miId.equals(c.ultimoRemitente) ? "Tú: " : "";
            h.tvUltimo.setText(prefijo + c.ultimoMensaje);
            h.tvUltimo.setTypeface(null, Typeface.NORMAL);
        }

        h.itemView.setOnClickListener(v -> listener.onClick(c));
    }

    @Override
    public int getItemCount() {
        return chats.size();
    }

    /** VIEWHOLDER: referencias a los elementos de una fila */
    static class ChatViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        TextView tvNombre, tvHora, tvUltimo;

        ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.ivAvatar);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvHora = itemView.findViewById(R.id.tvHora);
            tvUltimo = itemView.findViewById(R.id.tvUltimo);
        }
    }
}
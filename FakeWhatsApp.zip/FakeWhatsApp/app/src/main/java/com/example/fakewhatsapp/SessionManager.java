package com.example.fakewhatsapp;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Guarda la sesión del usuario en el celular (SharedPreferences).
 * Así, si cierra la app, sigue con la sesión iniciada.
 */
public class SessionManager {

    // Nombre del "archivo" donde se guardan los datos
    private static final String PREFS = "sesion_fakewhatsapp";
    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /**
     * Guarda los datos que regresa Supabase al iniciar sesión.
     * @param accessToken  JWT: el "pase" que demuestra quién es el usuario
     * @param refreshToken sirve para pedir un JWT nuevo cuando el actual caduca
     * @param expiresIn    segundos que dura el JWT (normalmente 3600 = 1 hora)
     * @param userId       id del usuario en Supabase
     */
    public void guardarSesion(String accessToken, String refreshToken, long expiresIn, String userId) {
        // Calculamos el momento exacto en que caduca el token
        long expiraEn = System.currentTimeMillis() + (expiresIn * 1000L);

        prefs.edit()
                .putString("access_token", accessToken)
                .putString("refresh_token", refreshToken)
                .putLong("expira_en", expiraEn)
                .putString("user_id", userId)
                .apply();
    }

    public String getAccessToken()  { return prefs.getString("access_token", null); }
    public String getRefreshToken() { return prefs.getString("refresh_token", null); }
    public String getUserId()       { return prefs.getString("user_id", null); }

    /** ¿Hay una sesión guardada? */
    public boolean haySesion() {
        return getAccessToken() != null;
    }

    /** ¿El JWT ya caducó? (le restamos 1 minuto para renovarlo antes de tiempo) */
    public boolean tokenExpirado() {
        long expiraEn = prefs.getLong("expira_en", 0);
        return System.currentTimeMillis() > (expiraEn - 60000);
    }

    /** Borra todos los datos de la sesión */
    public void cerrarSesion() {
        prefs.edit().clear().apply();
    }
}
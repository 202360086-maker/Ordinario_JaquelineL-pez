package com.example.fakewhatsapp;

import com.google.gson.annotations.SerializedName;

/**
 * MODELO: representa una fila de la tabla "profiles".
 * @SerializedName conecta el nombre de la columna en Supabase con la variable en Java.
 */
public class Perfil {

    @SerializedName("id")
    public String id;

    @SerializedName("username")
    public String username;

    @SerializedName("display_name")
    public String displayName;

    @SerializedName("avatar_url")
    public String avatarUrl;

    @SerializedName("about")
    public String about;
    @SerializedName("last_seen")
    public String lastSeen;  // última conexión (Fase 8)

    /** Nombre que se muestra: el display_name, o el username si no tiene */
    public String getNombreVisible() {
        if (displayName != null && !displayName.trim().isEmpty()) return displayName;
        return username != null ? username : "Sin nombre";
    }

    /** Info del perfil, o el mensaje clásico de WhatsApp si está vacía */
    public String getInfo() {
        if (about != null && !about.trim().isEmpty()) return about;
        return "¡Hola! Estoy usando FakeWhatsApp.";
    }
}
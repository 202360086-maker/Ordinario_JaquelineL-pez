package com.example.fakewhatsapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Pantalla de perfil: editar nombre, info y foto.
 */
public class PerfilActivity extends AppCompatActivity {

    private ImageView ivFoto;
    private EditText etNombre, etUsuario, etInfo;
    private Button btnGuardar;
    private ProgressBar progress;

    private PerfilRepository repo;
    private Uri fotoNueva = null; // foto elegida de la galería (si la cambió)

    // Abre la galería para elegir una imagen; al elegirla, la muestra
    private final ActivityResultLauncher<String> elegirFoto =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    fotoNueva = uri;
                    AvatarUtil.mostrar(ivFoto, uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        ivFoto = findViewById(R.id.ivFoto);
        etNombre = findViewById(R.id.etNombre);
        etUsuario = findViewById(R.id.etUsuario);
        etInfo = findViewById(R.id.etInfo);
        btnGuardar = findViewById(R.id.btnGuardar);
        progress = findViewById(R.id.progress);

        repo = new PerfilRepository(new SessionManager(this));

        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());
        // "image/*" = solo imágenes
        findViewById(R.id.btnCambiarFoto).setOnClickListener(v -> elegirFoto.launch("image/*"));
        ivFoto.setOnClickListener(v -> elegirFoto.launch("image/*"));
        btnGuardar.setOnClickListener(v -> guardar());

        AvatarUtil.mostrar(ivFoto, null);
        cargarPerfil();
    }

    /** Trae mis datos de Supabase y llena los campos */
    private void cargarPerfil() {
        cargando(true);
        repo.obtenerMiPerfil(new PerfilRepository.Callback<Perfil>() {
            @Override
            public void onExito(Perfil p) {
                cargando(false);
                etNombre.setText(p.getNombreVisible());
                etUsuario.setText(p.username);
                etInfo.setText(p.about);
                AvatarUtil.mostrar(ivFoto, p.avatarUrl);
            }

            @Override
            public void onError(String m) {
                cargando(false);
                Toast.makeText(PerfilActivity.this, "Error: " + m, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Guarda los cambios: primero sube la foto (si hay) y luego actualiza los datos */
    private void guardar() {
        String nombre = etNombre.getText().toString().trim();
        String info = etInfo.getText().toString().trim();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }

        cargando(true);

        if (fotoNueva != null) {
            byte[] imagen = comprimirImagen(fotoNueva);
            if (imagen == null) {
                cargando(false);
                Toast.makeText(this, "No se pudo leer la imagen", Toast.LENGTH_SHORT).show();
                return;
            }
            // 1) Subir foto → 2) guardar datos con la URL nueva
            repo.subirFoto(imagen, new PerfilRepository.Callback<String>() {
                @Override public void onExito(String url) { actualizarDatos(nombre, info, url); }
                @Override
                public void onError(String m) {
                    cargando(false);
                    Toast.makeText(PerfilActivity.this, "Error al subir foto: " + m, Toast.LENGTH_LONG).show();
                }
            });
        } else {
            actualizarDatos(nombre, info, null);
        }
    }

    /** Actualiza nombre, info y (si hay) la URL de la foto en la tabla profiles */
    private void actualizarDatos(String nombre, String info, String url) {
        repo.actualizarPerfil(nombre, info, url, new PerfilRepository.Callback<Void>() {
            @Override
            public void onExito(Void r) {
                Toast.makeText(PerfilActivity.this, "Perfil actualizado ✓", Toast.LENGTH_SHORT).show();
                finish();
            }

            @Override
            public void onError(String m) {
                cargando(false);
                Toast.makeText(PerfilActivity.this, "Error: " + m, Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * Reduce la foto a máximo 512 px y la convierte a JPEG.
     * Así se sube rápido y no ocupa mucho espacio.
     */
    private byte[] comprimirImagen(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            Bitmap original = BitmapFactory.decodeStream(in);
            if (original == null) return null;

            int max = 512;
            float escala = Math.min(1f, (float) max / Math.max(original.getWidth(), original.getHeight()));
            Bitmap chica = Bitmap.createScaledBitmap(original,
                    Math.round(original.getWidth() * escala),
                    Math.round(original.getHeight() * escala), true);

            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            chica.compress(Bitmap.CompressFormat.JPEG, 80, salida); // calidad 80%
            return salida.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private void cargando(boolean si) {
        progress.setVisibility(si ? View.VISIBLE : View.GONE);
        btnGuardar.setEnabled(!si);
    }
}
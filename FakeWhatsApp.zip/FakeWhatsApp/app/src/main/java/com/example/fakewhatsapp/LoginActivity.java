package com.example.fakewhatsapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;

/**
 * Pantalla de inicio de sesión.
 * Valida los datos, inicia sesión en Supabase y guarda el JWT.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etCorreo, etPassword;
    private Button btnEntrar;
    private ProgressBar progress;

    private final AuthRepository auth = new AuthRepository();
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);

        // Conectamos las variables con los IDs del XML
        etCorreo = findViewById(R.id.etCorreo);
        etPassword = findViewById(R.id.etPassword);
        btnEntrar = findViewById(R.id.btnEntrar);
        progress = findViewById(R.id.progress);
        TextView tvIrRegistro = findViewById(R.id.tvIrRegistro);
        TextView tvOlvide = findViewById(R.id.tvOlvide);

        // Acciones de los botones y enlaces
        btnEntrar.setOnClickListener(v -> iniciarSesion());
        tvIrRegistro.setOnClickListener(v -> startActivity(new Intent(this, RegistroActivity.class)));
        tvOlvide.setOnClickListener(v -> startActivity(new Intent(this, RecuperarActivity.class)));
    }

    private void iniciarSesion() {
        String correo = etCorreo.getText().toString().trim();
        String password = etPassword.getText().toString();

        // Validamos que no estén vacíos
        if (correo.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        cargando(true);
        auth.iniciarSesion(correo, password, new AuthRepository.AuthCallback() {
            @Override
            public void onExito(JsonObject r) {
                // Sacamos los datos de la respuesta de Supabase
                JsonObject user = r.getAsJsonObject("user");
                String userId = user.get("id").getAsString();
                String token = r.get("access_token").getAsString();

                // Guardamos la sesión en el celular
                session.guardarSesion(token,
                        r.get("refresh_token").getAsString(),
                        r.get("expires_in").getAsLong(),
                        userId);

                // Nombre guardado al registrarse (si no hay, usamos la parte antes del @)
                String nombre = correo.split("@")[0];
                JsonObject meta = user.getAsJsonObject("user_metadata");
                if (meta != null && meta.has("display_name")) {
                    nombre = meta.get("display_name").getAsString();
                }

                // Nos aseguramos de que exista su perfil y entramos
                auth.crearPerfil(token, userId, correo, nombre, new AuthRepository.AuthCallback() {
                    @Override public void onExito(JsonObject r2) { irAMain(); }
                    @Override public void onError(String m) { irAMain(); } // entra aunque falle el perfil
                });
            }

            @Override
            public void onError(String mensaje) {
                cargando(false);
                Toast.makeText(LoginActivity.this, "Error: " + mensaje, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** Abre la pantalla principal y borra el historial para no regresar al login con "atrás" */
    private void irAMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    /** Muestra u oculta el círculo de carga */
    private void cargando(boolean si) {
        progress.setVisibility(si ? View.VISIBLE : View.GONE);
        btnEntrar.setEnabled(!si);
    }
}
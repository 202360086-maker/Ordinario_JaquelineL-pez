package com.example.fakewhatsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * ADAPTER: conecta la lista de perfiles (datos) con el RecyclerView (pantalla).
 * Por cada contacto "infla" una fila (item_contacto.xml) y le pone sus datos.
 */
public class ContactoAdapter extends RecyclerView.Adapter<ContactoAdapter.ContactoViewHolder> {

    /** Interfaz para avisar a la Activity cuando tocan un contacto */
    public interface OnContactoClick {
        void onClick(Perfil perfil);
    }

    private final List<Perfil> todos = new ArrayList<>();    // lista completa
    private final List<Perfil> visibles = new ArrayList<>(); // lista filtrada por el buscador
    private final OnContactoClick listener;

    public ContactoAdapter(OnContactoClick listener) {
        this.listener = listener;
    }

    /** Recibe los contactos de Supabase */
    public void setContactos(List<Perfil> lista) {
        todos.clear();
        todos.addAll(lista);
        visibles.clear();
        visibles.addAll(lista);
        notifyDataSetChanged(); // avisa al RecyclerView que se redibuje
    }

    /** Filtra por nombre o usuario (para el buscador) */
    public void filtrar(String texto) {
        String t = texto.toLowerCase().trim();
        visibles.clear();
        for (Perfil p : todos) {
            boolean coincideNombre = p.getNombreVisible().toLowerCase().contains(t);
            boolean coincideUsuario = p.username != null && p.username.toLowerCase().contains(t);
            if (t.isEmpty() || coincideNombre || coincideUsuario) visibles.add(p);
        }
        notifyDataSetChanged();
    }

    public int getCantidadVisible() {
        return visibles.size();
    }

    /** Crea una fila nueva a partir del XML (solo se llama unas cuantas veces) */
    @NonNull
    @Override
    public ContactoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_contacto, parent, false);
        return new ContactoViewHolder(vista);
    }

    /** Llena una fila con los datos del contacto en esa posición */
    @Override
    public void onBindViewHolder(@NonNull ContactoViewHolder h, int position) {
        Perfil p = visibles.get(position);
        h.tvNombre.setText(p.getNombreVisible());
        h.tvInfo.setText(p.getInfo());
        AvatarUtil.mostrar(h.ivAvatar, p.avatarUrl);
        h.itemView.setOnClickListener(v -> listener.onClick(p));
    }

    @Override
    public int getItemCount() {
        return visibles.size();
    }

    /**
     * VIEWHOLDER: guarda las referencias a los elementos de UNA fila.
     * Así no se usa findViewById cada vez (más rápido).
     */
    static class ContactoViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        TextView tvNombre, tvInfo;

        ContactoViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.ivAvatar);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvInfo = itemView.findViewById(R.id.tvInfo);
        }
    }
}
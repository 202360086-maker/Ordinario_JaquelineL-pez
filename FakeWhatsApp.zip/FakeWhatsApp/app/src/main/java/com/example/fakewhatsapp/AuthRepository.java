package com.example.fakewhatsapp;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Todas las peticiones de autenticación:
 * registro, login, renovar token, recuperar contraseña, cerrar sesión y crear perfil.
 */
public class AuthRepository {

    /** Interfaz para avisarle a la pantalla si la petición salió bien o mal */
    public interface AuthCallback {
        void onExito(JsonObject respuesta);
        void onError(String mensaje);
    }

    // Regresa el resultado al hilo principal (el único que puede modificar la pantalla)
    private final Handler hiloPrincipal = new Handler(Looper.getMainLooper());

    // ---------------- REGISTRO ----------------
    public void registrar(String correo, String password, String nombre, AuthCallback cb) {
        JsonObject body = new JsonObject();
        body.addProperty("email", correo);
        body.addProperty("password", password);

        // "data" guarda información extra del usuario (aquí su nombre)
        JsonObject data = new JsonObject();
        data.addProperty("display_name", nombre);
        body.add("data", data);

        Request request = SupabaseClient.peticion("/auth/v1/signup", null)
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- INICIO DE SESIÓN ----------------
    public void iniciarSesion(String correo, String password, AuthCallback cb) {
        JsonObject body = new JsonObject();
        body.addProperty("email", correo);
        body.addProperty("password", password);

        Request request = SupabaseClient.peticion("/auth/v1/token?grant_type=password", null)
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- RENOVAR JWT ----------------
    public void renovarToken(String refreshToken, AuthCallback cb) {
        JsonObject body = new JsonObject();
        body.addProperty("refresh_token", refreshToken);

        Request request = SupabaseClient.peticion("/auth/v1/token?grant_type=refresh_token", null)
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- RECUPERAR CONTRASEÑA ----------------
    public void recuperarPassword(String correo, AuthCallback cb) {
        JsonObject body = new JsonObject();
        body.addProperty("email", correo);

        Request request = SupabaseClient.peticion("/auth/v1/recover", null)
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- CERRAR SESIÓN ----------------
    public void cerrarSesion(String accessToken, AuthCallback cb) {
        Request request = SupabaseClient.peticion("/auth/v1/logout", accessToken)
                .post(RequestBody.create("", SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- CREAR PERFIL EN LA TABLA profiles ----------------
    public void crearPerfil(String accessToken, String userId, String correo, String nombre, AuthCallback cb) {
        JsonObject perfil = new JsonObject();
        perfil.addProperty("id", userId);                      // mismo id que en Auth
        perfil.addProperty("username", correo.split("@")[0]);  // parte antes del @
        perfil.addProperty("display_name", nombre);

        Request request = SupabaseClient.peticion("/rest/v1/profiles", accessToken)
                // Si el perfil ya existe, no lo duplica ni lo sobrescribe
                .addHeader("Prefer", "resolution=ignore-duplicates,return=minimal")
                .post(RequestBody.create(perfil.toString(), SupabaseClient.JSON))
                .build();
        enviar(request, cb);
    }

    // ---------------- MÉTODO GENERAL PARA ENVIAR ----------------
    private void enviar(Request request, AuthCallback cb) {
        // enqueue = se ejecuta en segundo plano (Android no permite internet en el hilo principal)
        SupabaseClient.getClient().newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                hiloPrincipal.post(() -> cb.onError("Sin conexión: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String texto = response.body() != null ? response.body().string() : "";

                if (response.isSuccessful()) {
                    // Convertimos el texto a JSON (si viene vacío, mandamos un JSON vacío)
                    JsonObject json = texto.trim().startsWith("{")
                            ? JsonParser.parseString(texto).getAsJsonObject()
                            : new JsonObject();
                    hiloPrincipal.post(() -> cb.onExito(json));
                } else {
                    String error = extraerError(texto);
                    hiloPrincipal.post(() -> cb.onError(error));
                }
            }
        });
    }

    /** Supabase manda el error con distintos nombres; aquí buscamos el que venga */
    private String extraerError(String texto) {
        try {
            JsonObject json = JsonParser.parseString(texto).getAsJsonObject();
            if (json.has("msg")) return json.get("msg").getAsString();
            if (json.has("error_description")) return json.get("error_description").getAsString();
            if (json.has("message")) return json.get("message").getAsString();
        } catch (Exception ignored) { }
        return texto;
    }
}
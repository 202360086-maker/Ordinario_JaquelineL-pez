package com.example.fakewhatsapp;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Conexión en TIEMPO REAL con Supabase Realtime usando un WebSocket.
 * - postgres_changes: avisa cuando se INSERTA o ACTUALIZA un mensaje del chat
 * - broadcast: mensajes rápidos entre usuarios ("está escribiendo...")
 */
public class RealtimeClient {

    /** La pantalla del chat implementa esto para recibir los avisos */
    public interface Listener {
        void onMensajeNuevo(Mensaje m);
        void onMensajeActualizado(Mensaje m);
        void onEscribiendo(String userId);
    }

    private final Gson gson = new Gson();
    private final Handler hiloPrincipal = new Handler(Looper.getMainLooper());
    private WebSocket ws;
    private String topic;  // "canal" de esta conversación
    private int ref = 1;   // número de mensaje (lo pide el protocolo)

    // "Latido" cada 25 s para que el servidor no cierre la conexión
    private final Runnable latido = new Runnable() {
        @Override
        public void run() {
            if (ws != null) {
                enviar("phoenix", "heartbeat", new JsonObject());
                hiloPrincipal.postDelayed(this, 25000);
            }
        }
    };

    /** Conecta y se suscribe a los cambios de UNA conversación */
    public void conectar(String convId, String token, Listener listener) {
        topic = "realtime:chat-" + convId;

        String url = SupabaseClient.SUPABASE_URL.replace("https://", "wss://")
                + "/realtime/v1/websocket?apikey=" + SupabaseClient.SUPABASE_KEY + "&vsn=1.0.0";

        Request request = new Request.Builder().url(url).build();
        ws = SupabaseClient.getClient().newWebSocket(request, new WebSocketListener() {

            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                // ---- Suscribirse a cambios en messages de ESTA conversación ----
                JsonObject cambios = new JsonObject();
                cambios.addProperty("event", "*"); // INSERT y UPDATE
                cambios.addProperty("schema", "public");
                cambios.addProperty("table", "messages");
                cambios.addProperty("filter", "conversation_id=eq." + convId);
                JsonArray listaCambios = new JsonArray();
                listaCambios.add(cambios);

                JsonObject broadcast = new JsonObject();
                broadcast.addProperty("self", false); // no recibir mis propios "escribiendo"

                JsonObject presence = new JsonObject();
                presence.addProperty("key", "");

                JsonObject config = new JsonObject();
                config.add("broadcast", broadcast);
                config.add("presence", presence);
                config.add("postgres_changes", listaCambios);
                config.addProperty("private", false);

                JsonObject payload = new JsonObject();
                payload.add("config", config);
                payload.addProperty("access_token", token); // JWT: para respetar las reglas RLS

                enviar(topic, "phx_join", payload);
                hiloPrincipal.postDelayed(latido, 25000);
            }

            @Override
            public void onMessage(WebSocket webSocket, String texto) {
                procesar(texto, listener);
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response r) {
                hiloPrincipal.removeCallbacks(latido);
            }
        });
    }

    /** Lee lo que manda Supabase y avisa a la pantalla */
    private void procesar(String texto, Listener listener) {
        try {
            JsonObject msg = JsonParser.parseString(texto).getAsJsonObject();
            String evento = msg.get("event").getAsString();

            if ("postgres_changes".equals(evento)) {
                // Cambio en la base de datos
                JsonObject data = msg.getAsJsonObject("payload").getAsJsonObject("data");
                String tipo = data.get("type").getAsString(); // INSERT o UPDATE
                Mensaje m = gson.fromJson(data.getAsJsonObject("record"), Mensaje.class);

                hiloPrincipal.post(() -> {
                    if ("INSERT".equals(tipo)) listener.onMensajeNuevo(m);
                    else if ("UPDATE".equals(tipo)) listener.onMensajeActualizado(m);
                });

            } else if ("broadcast".equals(evento)) {
                // Aviso de "escribiendo..."
                JsonObject p = msg.getAsJsonObject("payload");
                if ("typing".equals(p.get("event").getAsString())) {
                    String userId = p.getAsJsonObject("payload").get("user_id").getAsString();
                    hiloPrincipal.post(() -> listener.onEscribiendo(userId));
                }
            }
        } catch (Exception ignored) { }
    }

    /** Avisa al otro usuario que estoy escribiendo */
    public void enviarEscribiendo(String miId) {
        JsonObject datos = new JsonObject();
        datos.addProperty("user_id", miId);

        JsonObject payload = new JsonObject();
        payload.addProperty("type", "broadcast");
        payload.addProperty("event", "typing");
        payload.add("payload", datos);

        enviar(topic, "broadcast", payload);
    }

    /** Envía un mensaje con el formato del protocolo de Supabase Realtime */
    private void enviar(String topico, String evento, JsonObject payload) {
        if (ws == null) return;
        JsonObject msg = new JsonObject();
        msg.addProperty("topic", topico);
        msg.addProperty("event", evento);
        msg.add("payload", payload);
        msg.addProperty("ref", String.valueOf(ref++));
        ws.send(msg.toString());
    }

    /** Cierra la conexión al salir del chat */
    public void desconectar() {
        hiloPrincipal.removeCallbacks(latido);
        if (ws != null) {
            ws.close(1000, "Salió del chat");
            ws = null;
        }
    }
}
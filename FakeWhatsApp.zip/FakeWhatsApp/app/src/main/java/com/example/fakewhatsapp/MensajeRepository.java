package com.example.fakewhatsapp;

import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Peticiones de mensajes (Fase 6) y estados (Fase 8):
 * historial, enviar, marcar recibidos/leídos y última conexión.
 */
public class MensajeRepository {

    public interface Callback<T> {
        void onExito(T resultado);
        void onError(String mensaje);
    }

    private final SessionManager session;
    private final Gson gson = new Gson();
    private final Handler hiloPrincipal = new Handler(Looper.getMainLooper());

    public MensajeRepository(SessionManager session) {
        this.session = session;
    }

    // ---------------- CONSULTAR HISTORIAL ----------------
    public void listarMensajes(String convId, Callback<List<Mensaje>> cb) {
        String ruta = "/rest/v1/messages?select=*&conversation_id=eq." + convId + "&order=created_at.asc";
        Request request = SupabaseClient.peticion(ruta, session.getAccessToken()).get().build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String texto) {
                Mensaje[] lista = gson.fromJson(texto, Mensaje[].class);
                cb.onExito(new ArrayList<>(Arrays.asList(lista)));
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- INSERTAR MENSAJE EN POSTGRESQL ----------------
    public void enviarMensaje(String convId, String texto, Callback<Mensaje> cb) {
        JsonObject body = new JsonObject();
        body.addProperty("conversation_id", convId);
        body.addProperty("sender_id", session.getUserId());
        body.addProperty("content", texto);
        body.addProperty("type", "text");
        // status se pone solo en 'sent' (valor por defecto de la columna)

        Request request = SupabaseClient.peticion("/rest/v1/messages", session.getAccessToken())
                .addHeader("Prefer", "return=representation") // que regrese el mensaje creado
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String t) {
                Mensaje[] creado = gson.fromJson(t, Mensaje[].class);
                cb.onExito(creado[0]);
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- ESTADOS (FASE 8) ----------------
    /** Marca como leídos los mensajes que me mandaron en este chat */
    public void marcarLeidos(String convId) {
        JsonObject body = new JsonObject();
        body.addProperty("conv", convId);
        rpc("marcar_leidos", body);
    }

    /** Marca como recibidos todos los mensajes que me han llegado */
    public void marcarRecibidos() {
        rpc("marcar_recibidos", new JsonObject());
    }

    /** Guarda mi última conexión (ahora) */
    public void actualizarConexion() {
        rpc("actualizar_conexion", new JsonObject());
    }

    /** Trae el perfil de otra persona (para saber su última conexión) */
    public void obtenerPerfil(String userId, Callback<Perfil> cb) {
        Request request = SupabaseClient.peticion("/rest/v1/profiles?select=*&id=eq." + userId,
                session.getAccessToken()).get().build();

        ejecutar(request, new Callback<String>() {
            @Override
            public void onExito(String t) {
                Perfil[] p = gson.fromJson(t, Perfil[].class);
                if (p.length > 0) cb.onExito(p[0]);
            }
            @Override public void onError(String m) { cb.onError(m); }
        });
    }

    // ---------------- AYUDANTES ----------------
    /** Llama una función SQL de Supabase sin esperar respuesta */
    private void rpc(String funcion, JsonObject body) {
        Request request = SupabaseClient.peticion("/rest/v1/rpc/" + funcion, session.getAccessToken())
                .post(RequestBody.create(body.toString(), SupabaseClient.JSON))
                .build();
        ejecutar(request, null);
    }

    private void ejecutar(Request request, Callback<String> cb) {
        SupabaseClient.getClient().newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (cb != null) hiloPrincipal.post(() -> cb.onError("Sin conexión: " + e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String texto = response.body() != null ? response.body().string() : "";
                if (cb == null) return; // nadie espera respuesta
                if (response.isSuccessful()) {
                    hiloPrincipal.post(() -> cb.onExito(texto));
                } else {
                    String error = extraerError(texto);
                    hiloPrincipal.post(() -> cb.onError(error));
                }
            }
        });
    }

    private String extraerError(String texto) {
        try {
            JsonObject json = JsonParser.parseString(texto).getAsJsonObject();
            if (json.has("message")) return json.get("message").getAsString();
        } catch (Exception ignored) { }
        return texto;
    }
}
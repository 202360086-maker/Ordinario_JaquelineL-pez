package com.example.fakewhatsapp;

import com.google.gson.annotations.SerializedName;

/** MODELO: una fila de la tabla "messages" */
public class Mensaje {

    @SerializedName("id")
    public String id;

    @SerializedName("conversation_id")
    public String conversationId;

    @SerializedName("sender_id")
    public String senderId;        // quién lo envió

    @SerializedName("content")
    public String content;         // texto

    @SerializedName("type")
    public String type;            // "text"

    @SerializedName("status")
    public String status;          // "sent", "delivered" o "read"

    @SerializedName("created_at")
    public String createdAt;       // fecha y hora
}
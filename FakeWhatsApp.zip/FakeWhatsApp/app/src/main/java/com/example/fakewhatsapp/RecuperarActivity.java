package com.example.fakewhatsapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonObject;

/**
 * Pantalla para recuperar contraseña.
 * Supabase envía al correo un enlace para crear una contraseña nueva.
 */
public class RecuperarActivity extends AppCompatActivity {

    private final AuthRepository auth = new AuthRepository();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar);

        EditText etCorreo = findViewById(R.id.etCorreo);
        Button btnEnviar = findViewById(R.id.btnEnviar);
        ProgressBar progress = findViewById(R.id.progress);

        // Flecha para regresar al login
        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());

        btnEnviar.setOnClickListener(v -> {
            String correo = etCorreo.getText().toString().trim();
            if (correo.isEmpty()) {
                Toast.makeText(this, "Escribe tu correo", Toast.LENGTH_SHORT).show();
                return;
            }

            // Mostramos carga y desactivamos el botón
            progress.setVisibility(View.VISIBLE);
            btnEnviar.setEnabled(false);

            auth.recuperarPassword(correo, new AuthRepository.AuthCallback() {
                @Override
                public void onExito(JsonObject r) {
                    Toast.makeText(RecuperarActivity.this,
                            "Te enviamos un enlace a tu correo", Toast.LENGTH_LONG).show();
                    finish(); // regresa al login
                }

                @Override
                public void onError(String mensaje) {
                    progress.setVisibility(View.GONE);
                    btnEnviar.setEnabled(true);
                    Toast.makeText(RecuperarActivity.this, "Error: " + mensaje, Toast.LENGTH_LONG).show();
                }
            });
        });
    }
}